Shadowman Report Changes by Release
=================================

1.9.1 - Released 18-Nov-2024
----------------------------

Changes
```````
- Changed default var of detailedreport in Linux and Windows report to be a String

1.9.0 - Released 9-Jul-2024
----------------------------

Changes
```````
- Added Active Directory Report

1.8.0 - Released 10-Jun-2024
----------------------------

Changes
```````
- Added Google Cloud report

1.7.1 - Released 13-Dec-2023
----------------------------

Changes
```````
- Added aws ability to tags report

1.7.0 - Released 13-Dec-2023
----------------------------

Changes
```````
- Added aws report which has detailed AWS information across all regions

1.6.0 - Released 04-May-2023
----------------------------

Changes
```````
- Added azure report which has detailed Azure information across all regions

1.5.0 - Released 18-Apr-2023
----------------------------

Changes
```````
- Added certificate report

1.3.0 - Released 27-May-2022
----------------------------

Changes
```````
- Fixed error with no changelog
